// app/signin/page.tsx
import Signin from "@/components/Signin";

const SigninPage = () => <Signin />;

export default SigninPage;
