// app/signout/page.tsx
import Signout from "@/components/Signout";

const SignoutPage = () => <Signout />;

export default SignoutPage;
