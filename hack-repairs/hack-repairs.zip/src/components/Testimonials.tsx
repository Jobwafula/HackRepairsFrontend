import React from 'react';
import Review from './testimonial/Review';

const Testimonials = () => {
  return (
    <div >
      <Review />
      
    </div>
  );
};

export default Testimonials;
